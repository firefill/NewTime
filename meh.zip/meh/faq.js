question1.addEventListener('click', ()=>{
    answer1.classList.toggle('hidden')
    miniava1.style.height=20+'px'
})
question2.addEventListener('click', ()=>{
    answer2.classList.toggle('hidden')
    miniava2.style.height=20+'px'
})
question3.addEventListener('click', ()=>{
    answer3.classList.toggle('hidden')
    miniava3.style.height=20+'px'
})
question4.addEventListener('click', ()=>{
    answer4.classList.toggle('hidden')
    miniava4.style.height=20+'px'
})
question5.addEventListener('click', ()=>{
    answer5.classList.toggle('hidden')
    miniava5.style.height=20+'px'
})
question6.addEventListener('click', ()=>{
    answer6.classList.toggle('hidden')
    miniava6.style.height=20+'px'
})
question7.addEventListener('click', ()=>{
    answer7.classList.toggle('hidden')
    miniava7.style.height=20+'px'
})